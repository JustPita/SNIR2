#pragma once
#include <string>
#include <vector>

class Voiture;
class Moteur
{
    public:
    Voiture *laVoiture;
    void vidanger();
    Moteur();
};